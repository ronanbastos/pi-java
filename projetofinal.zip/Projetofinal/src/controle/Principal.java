package controle;

import visao.*;

public class  Principal {

	public static void main(String[] args) {
		
	TelaInicial tI = new TelaInicial();
	tI.getClass();
		//TelaCadVeiculo tI = new TelaCadVeiculo();
		//tI.getClass();	
	}

}
